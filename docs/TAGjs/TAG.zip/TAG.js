//Player------------------------------------------------------------------------
var Player = new Entity("player",
  STARTING_ROOM,
  "you",
  {
    "do a barrel roll": function() {
      output("Press Z or R twice!");
    },
    zz: function() {
      output("You have done a barrel roll");
    },
    rr: function() {
      output("You have done a barrel roll");
    },
    inventory: function() {
      var inventory = findByName("Inventory", getRooms());
      var description = describeEntities(inventory);
      if (description.length > 0) {
        output("You have " + describeEntities(inventory) + ".");
      } else {
        output("You have nothing.");
      }
    },
    nothing: function() {
      var room = findByName(getPlayerLocation(), getRooms());
      var exits = Object.keys(getCurrentExits());
      exits = exits.concat(Object.keys(getInterceptorExits(room)));
      for (var i = 0; i < exits.length; i++) {
        if(getInput() == exits[i]) {
          var player = getPlayer();
          player.methods.move();
          return;
        }
      }
      output("I'm afraid I don't understand.");
    },
    move: function() {
      var input = getInput();
      movePlayerByInput(input);
    },
    look: function() {
      var player = getPlayer();
      var currentRoom = findByName(player.location, getRooms());
      updateRoomDisplay(currentRoom);
    },
    use: function() {
      output("Use what?");
    },
    throw: function() {
      output("Throw what?");
    },
  },
  "player"
);
function getPlayer() {
  return Player;
}
function getPlayerLocation() {
  var player = getPlayer();
  return player.location;
}
function inventoryContains(name) {
  var inventory = narrowEntitiesByLocation(getEntities(), "Inventory");
  var item = findByName(name, inventory);
  if (typeof item == "object") {
    return true;
  }
  return false;
}
//I/O Processing----------------------------------------------------------------
function enterHandler() {
  var outputBox = document.getElementById("outputBox");
  var inputBox = document.getElementById("inputBox");
  var input = inputBox.value;
  output(input);
  var player = getPlayer();
  var playerLocation = player.location;
  var parsedInput = parseInput(input, playerLocation);
  executeParsedInput(parsedInput);
  inputBox.value = "";
}
function output(str) {
  var outputBox = document.getElementById("outputBox");
  outputBox.innerHTML += "<br>>" + str;
  outputBox.scrollTop = outputBox.scrollHeight;
}
function listenForKey(e, key, callback) {
  if (e.key == key) {
    callback();
  }
}
//Input Processing--------------------------------------------------------------
function testForWord(input, word) {
  input = input.toLowerCase();
  word = word.toLowerCase();
  var synonyms = getSynonyms(word);
  if (synonyms) {
    for (var j = 0; j < synonyms.length; j++) {
      if (input.includes(synonyms[j])) {
        return true;
      }
    }
  } else if (input.includes(word)) {
    return true;
  } else {
    return false;
  }
}
function getSynonyms(word) {;
  return SYNONYMS[word];
}
function getInput() {
  var inputBox = document.getElementById("inputBox");
  return inputBox.value;
}
function detectEntity(input, entities) {
  for (var i = 0; i < entities.length; i++) {
    var entity = entities[i];
    var entityName = entity.givenName;
    if (testForWord(input, entityName)) {
      return entity;
    }
  }
  return getPlayer();
}
function detectAction(input, subject) {
  var methodKeys = Object.keys(subject.methods);
  for (var i = 0; i < methodKeys.length; i++) {
    if(testForWord(input, methodKeys[i])) {
      return methodKeys[i];
    }
  }
  return "nothing";
}
function parseInput(input) {
  var location = getPlayerLocation();
  var entities = getEntities().concat(getObstructions());
  entities = narrowEntitiesByLocation(entities, location);
  var subject = detectEntity(input, entities);
  if (subject == getPlayer()) {
    entities = narrowEntitiesByLocation(getEntities(), "Inventory");
    subject = detectEntity(input, entities);
  }
  var action = detectAction(input, subject);
  return [subject, action];
}
function executeParsedInput(parsedInput) {
  var subject = parsedInput[0];
  var action = parsedInput[1];
  subject.methods[action]();
}
//Setup-------------------------------------------------------------------------
function inputSetup() {
  var inputBox = document.getElementById("inputBox");
  inputBox.onkeydown = function() {listenForKey(event, "Enter", enterHandler);};
  inputBox.focus();
}
function imageSetup(room) {
  var image = document.getElementById("imageDisplay");
  if (USE_IMAGES == true) {
    updateImageDisplay(room.image);
  } else {
    var outputBox = document.getElementById("outputBox");
    outputBox.style.height = "75%";
    image.style.width = 0;
    image.style.height = 0;
  }
}
function setup() {
  var startingRoom = findByName(STARTING_ROOM, getRooms());
  inputSetup();
  imageSetup(startingRoom);
  updateRoomDisplay(startingRoom);
}
//Display-----------------------------------------------------------------------
function updateImageDisplay(image) {
  var imageDisplay = document.getElementById("imageDisplay");
  if (USE_IMAGES == true) {
    imageDisplay.src = image;
  }
}
function updateNameDisplay(str) {
  var nameDisplay = document.getElementById("roomNameDisplay");
  nameDisplay.innerHTML = str;
}
function updateRoomDisplay(room) {
  var givenName = room.givenName;
  var image = room.image;
  updateNameDisplay(givenName);
  updateImageDisplay(image);
  var entities = narrowEntitiesByLocation(getEntities(), room.name);
  var exits = getCurrentExits();
  var exitKeys = Object.keys(exits);
  var obstructions = narrowEntitiesByLocation(getObstructions(), room.name);
  var interceptorExits = getInterceptorExits(room);
  var interceptorKeys = Object.keys(interceptorExits);
  var description = "";
  description += describe(room);
  if (entities.length > 0) {
    description += " There's " + describeEntities(room) + ".";
  }
  if (exitKeys.length > 0) {
    description += " You can " + describeExits(exitKeys, exits) + ".";
  }
  if (obstructions.length > 0) {
    description += " However, " + describeObstructions(room) + ".";
  }
  if (interceptorKeys.length > 0) {
    description += " You can also " + describeExits(interceptorKeys, interceptorExits) + ".";
  }
  output(description);
}
function describe(room) {
  return room.description;
}
function describeEntities(room) {
  var description = ""
  var entities = getEntities();
  var playerLocation = getPlayerLocation();
  var narrowedEntities = narrowEntitiesByLocation(entities, room.name);
  for (var i = 0; i < narrowedEntities.length; i++) {
    var entity = narrowedEntities[i];
    var entityDescription = embolden(entity.description, entity.givenName);
    description += manageEntityGrammar(entityDescription, narrowedEntities.length, i);
  }
    return description;
}
function describeExits(keys, exits) {
  var description = "";
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var exitDescription = embolden(exits[key][1], key);
    if (i == 0) {
      description += exitDescription;
    } else if (i < keys.length - 1) {
      description += ", " + exitDescription;
    } else if (i >= keys.length - 1) {
      description += " or " + exitDescription;
    }
  }
  return(description);
}
function describeObstructions(room) {
  var description = ""
  var entities = getObstructions();
  var playerLocation = getPlayerLocation();
  var narrowedEntities = narrowEntitiesByLocation(entities, room.name);
  for (var i = 0; i < narrowedEntities.length; i++) {
    var entity = narrowedEntities[i];
    var entityDescription = embolden(entity.exit[1], entity.givenName);
    entityDescription = embolden(entityDescription, entity.exit[0]);
    description += manageEntityGrammar(entityDescription, length, i);
  }
  return description;
}
function manageEntityGrammar(entityDescription, length, i) {
  if (i == 0) {
    return entityDescription;
  } else if (i < length - 1) {
    return ", " + entityDescription;
  } else if (i >= length - 1) {
    return " and " + entityDescription;
  }
}
function embolden(string, substr) {
  var re = new RegExp(substr, "i");
  var index = string.search(re);
  var strA = string.slice(0, index);
  var strB = string.slice(index + substr.length);
  var substrings = string.split(re);
  var description = strA + "<strong>" + substr + "</strong>" + strB;
  return description;
}
//Rooms-------------------------------------------------------------------------
function Room(name, image, description, exits, givenName) {
  this.name = name;
  this.image = image;
  this.description = description;
  this.exits = exits;
  this.givenName = givenName;
}
function findByName(name, arr) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i].name == name) {
      return arr[i];
    }
  }
}
function getCurrentExits() {
  var rooms = getRooms();
  var location = getPlayerLocation();
  var room = findByName(location, rooms);
  return room.exits;
}
function getRooms() {
  return ROOM_ARRAY;
}
//Movement----------------------------------------------------------------------
function warp(entity, roomName) {
  if (roomName) {
    entity.location = roomName;
  };
}
function moveEntity(entity, direction) {
  var currentRoom = findByName(entity.location, getRooms());
  var exits = currentRoom.exits;
  var interceptors = narrowEntitiesByLocation(getInterceptors, entity.location);
  var interceptorExits = getInterceptorExits(currentRoom);
  if (interceptorExits[direction]) {
    warp(entity, interceptorExits[direction][0]);
  }
  if (exits[direction]) {
    warp(entity, exits[direction][0]);
  }

}
function movePlayerByInput(input) {
  var player = getPlayer();
  var currentRoom = findByName(player.location, getRooms());
  var obstruction = testForObstructions(getInput(), currentRoom);
  var direction = testForExits(getInput(), currentRoom);
  if (obstruction) {
    var description = embolden(obstruction.exit[1], obstruction.exit[0]);
    description = embolden(description, obstruction.givenName);
    output(description + ".");
    return;
  }
  if (direction) {
    moveEntity(player, direction);
    var newRoom = findByName(player.location, getRooms());
    updateRoomDisplay(newRoom);
    return;
  }
  output("You can't go that way.");
}
function testForObstructions(input, room) {
  var obstructions = getObstructions();
  obstructions = narrowEntitiesByLocation(obstructions, room.name);
  for (var i = 0; i < obstructions.length; i++) {
    var exit = obstructions[i].exit[0];
    if (testForWord(getInput(), exit)) {
      return obstructions[i];
    }
  }
  return false;
}
function testForExits(input, room) {
  var player = getPlayer();
  var exits = Object.keys(room.exits);
  exits = exits.concat(Object.keys(getInterceptorExits(room)));
  for (var i = 0; i < exits.length; i++) {
    var exit = exits[i]
    if (testForWord(input, exit)) {
      return exit;
    }
  }
  return false;
}
//Objects-----------------------------------------------------------------------
//Entities----------------------------------------------------------------------
function Entity(name, location, description, methods, givenName) {
  this.name = name;
  this.description = description;
  this.location = location;
  this.methods = methods;
  this.givenName = givenName;
}
function getEntities() {
  return entityArray;
}
function narrowEntitiesByLocation(entities, location) {
  var narrowedEntities = [];
  for (var i = 0; i < entities.length; i++) {
    var entity = entities[i];
    if (entity.location == location) {
      narrowedEntities.push(entity);
    }
  }
  return narrowedEntities;
}
//Obstructions------------------------------------------------------------------
function Obstruction(name, location, methods, exit, givenName) {
  this.name = name;
  this.location = location;
  this.methods = methods;
  this.exit = exit;
  this.givenName = givenName;
}
function getObstructions() {
  return obstructionArray;
}
//Interceptors------------------------------------------------------------------
function Interceptor(name, location, exits) {
  this.name = name;
  this.location = location;
  this.exits = exits;
}
function getInterceptors() {
  return interceptorArray;
}
function getInterceptorExits(room) {
  var interceptors = narrowEntitiesByLocation(getInterceptors(), room.name);
  var exitArray = {};
  for (var i = 0; i < interceptors.length; i++) {
    var interceptor = interceptors[i];
    var exitKeys = Object.keys(interceptor.exits);
    for (var j = 0; j < exitKeys.length; j++) {
      var exitKey = exitKeys[j];
      exitArray[exitKey] = interceptor.exits[exitKey];
    }
  }
  return exitArray;
}
